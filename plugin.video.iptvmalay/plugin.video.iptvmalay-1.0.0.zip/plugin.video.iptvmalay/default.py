import sys
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'movies')

url = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch001.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1447990442&myTokenPrefixhash=N_UF4WhAacIcLkI0w5WS72S4wMkfBn6tMtmlmnrdCq8='
li = xbmcgui.ListItem(label='TV1')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv1.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch002.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1447990481&myTokenPrefixhash=zinD-Us8EaKapydVmeR3v_gYLUm01OBsqv8AADS3HBc='
li = xbmcgui.ListItem('TV2')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv2.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://tv3liveios-i.akamaihd.net/hls/live/205900/ios/tv3live/master.m3u8'
li = xbmcgui.ListItem('TV3')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv3.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://ntv7liveios-i.akamaihd.net/hls/live/205902/ios/ntv7live/master.m3u8'
li = xbmcgui.ListItem('NTV7')
li.setIconImage('http://myiptv.site40.net/kodi/logo/ntv7.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://8tvliveios-i.akamaihd.net/hls/live/205901/ios/8tvlive/master.m3u8'
li = xbmcgui.ListItem('8TV')
li.setIconImage('http://myiptv.site40.net/kodi/logo/8tv.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://tv9liveios-i.akamaihd.net/hls/live/205903/ios/tv9live/master.m3u8'
li = xbmcgui.ListItem('TV9')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv9.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://d2f9tqsihrp4sc.cloudfront.net/livecf/smil:myStream.smil/playlist.m3u8'
li = xbmcgui.ListItem('AL-Hijrah')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv_alhijrah.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://goo.gl/FSrrbv'
li = xbmcgui.ListItem('Ria')
li.setIconImage('http://myiptv.site40.net/kodi/logo/mobtv.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch003.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1447990516&myTokenPrefixhash=-wCGJ4v2VRHlmfqHRmGkLvsDHHswSzvM-NniLHy4bVM='
li = xbmcgui.ListItem('TVi')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tvi.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch004.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1447990548&myTokenPrefixhash=0Hq4qxBWngGN6dK_HzBDx_wqwdDHIoNFC9iEF_-m3-U='
li = xbmcgui.ListItem('Muzik Aktif')
li.setIconImage('http://myiptv.site40.net/kodi/logo/muzik.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://awaniioslive-i.akamaihd.net/hls/live/207096-b/awaniIOSLiveStream@207096/awani_stream.m3u8'
li = xbmcgui.ListItem('AWANI')
li.setIconImage('http://myiptv.site40.net/kodi/logo/astro_awani.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://d22b8vh21p20bg.cloudfront.net/mylive/smil:bernama2_all.smil/playlist.m3u8'
li = xbmcgui.ListItem('BERNAMA TV')
li.setIconImage('http://myiptv.site40.net/kodi/logo/bernama.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://livestreaming-1528489630.ap-southeast-1.elb.amazonaws.com/liveedge/smil:rtm-ch006.smil/playlist.m3u8?myTokenPrefixstarttime=0&myTokenPrefixendtime=1447990590&myTokenPrefixhash=fPgdA8EYHnolnOCi2GmSCG2Mvtcahp0hXZ_urzUZ5JI='
li = xbmcgui.ListItem('1NEWS')
li.setIconImage('http://myiptv.site40.net/kodi/logo/1news.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)