import sys
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])

xbmcplugin.setContent(addon_handle, 'movies')

url = 'http://rtm-live.glueapi.io/smil:ch001.smil/playlist.m3u8?t=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpIjoiMTAxNDkiLCJtIjoicHJvdmlzaW9uaW5nIiwiciI6ImNkbi1ydG0tcGxhWVyLmdsdWVtcHNhcHAuY29tIiwiZCI6MTQ2MjczMTY1N30.jQxQqExLcnb6ivEgZkSFW66kjYpiQt9VmjK4TMbgRJTcl86fDjLeo2cA7QS4HUxAPP3leKXBidvlDKYUoXF0ug'
li = xbmcgui.ListItem(label='TV1')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv1.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://rtm-live.glueapi.io/smil:rtm-ch002/playlist.m3u8?t=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpIjoiMTAxNDgiLCJtIjoicHJvdmlzaW9uaW5nIiwiciI6ImNkbi1ydG0tcGxheWVyLmdsdWVtcHNhcHAuY29tIiwiZCI6MTQ2MjczMjA1Nn0.VR27yLPA80udhrteAhY1kzoiu3P1HQ2LfEjL2LsrH7xfMt58cDynVaMyJ1r-_fJ3_EY85MwB9hLb_WpIOu8AAw'
li = xbmcgui.ListItem('TV2')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv2.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://rtm-live.glueapi.io/smil:rtm-ch003.smil/playlist.m3u8?t=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpIjoiMTAxNTAiLCJtIjoicHJvdmlzaW9uaW5nIiwiciI6Im15a2xpay5ydG0uZ292Lm15IiwiZCI6MTQ2MzM2NTA5OX0.QCguZcsE7-CealvjYrhbUoJwxSvACq0iW7DzMXHl2ketAjIyCp0acsJo-u-HKv6HGUP96bXD6Vtmntnsv8640A'
li = xbmcgui.ListItem('TVi')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tvi.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://rtm-live.glueapi.io/smil:rtm-ch004/playlist.m3u8?t=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpIjoiMTAxNTEiLCJtIjoicHJvdmlzaW9uaW5nIiwiciI6Im15a2xpay5ydG0uZ292Lm15IiwiZCI6MTQ2MzM2NTEzM30.H7VcAV24RVdhCnqHij0XO4mCG-p_h7qojJ3uVD2Aoer2QRdPlhUDjyggw1SH79rA1f96mQg0abxgNxOTcirTRQ'
li = xbmcgui.ListItem('Galaksi Muzik')
li.setIconImage('http://myiptv.site40.net/kodi/logo/muzik.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://d2f9tqsihrp4sc.cloudfront.net/livecf/smil:tvah_hypptv.smil/playlist.m3u8'
li = xbmcgui.ListItem('AL-Hijrah TV')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv_alhijrah.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'rtmp://118.97.183.196/jhos//kbs'
li = xbmcgui.ListItem('KBS World')
li.setIconImage('http://myiptv.site40.net/kodi/logo/tv_alhijrah.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://playback01.aotg-video.astro.com.my/AOTGHLS/master_AWANI.m3u8'
li = xbmcgui.ListItem('AWANI')
li.setIconImage('http://myiptv.site40.net/kodi/logo/astro_awani.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://d22b8vh21p20bg.cloudfront.net/mylive/smil:bernama2_all.smil/chunklist_w774237887_b878000_sleng.m3u8'
li = xbmcgui.ListItem('BERNAMA TV')
li.setIconImage('http://myiptv.site40.net/kodi/logo/bernama.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

url = 'http://rtm-live.glueapi.io/smil:rtm-ch006/playlist.m3u8?t=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpIjoiMTAxNTMiLCJtIjoicHJvdmlzaW9uaW5nIiwiciI6Im15a2xpay5ydG0uZ292Lm15IiwiZCI6MTQ2MzM2NTE2M30.9qBB5nbibOWzvKHxIU57lJiH4FF2iM_FgG_Pcel5OeDq7zX0sUauqEwpS8h-u4vLtjfxgHOzwpMDnEPCdbmvMg'
li = xbmcgui.ListItem('1NEWS')
li.setIconImage('http://myiptv.site40.net/kodi/logo/1news.png')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)