import xbmcaddon

MainBase = 'https://goo.gl/cpeHW5'
addon = xbmcaddon.Addon('plugin.video.iptvmalay')