import xbmcaddon

MainBase = 'https://goo.gl/AvQIGi'
addon = xbmcaddon.Addon('plugin.video.muvemalay')