import xbmcaddon

MainBase = 'https://goo.gl/gIH5p6'
addon = xbmcaddon.Addon('plugin.video.muvemalay')