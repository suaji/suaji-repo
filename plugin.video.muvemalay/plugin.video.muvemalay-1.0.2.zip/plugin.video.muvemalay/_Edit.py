import xbmcaddon

MainBase = 'http://goo.gl/yCsj9B'
addon = xbmcaddon.Addon('plugin.video.muvemalay')